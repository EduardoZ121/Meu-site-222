# Premium UI v2 — Landing + Artistic

## Ficheiros (4)
- frontend/src/sections/Hero.jsx                              (REWRITE)
- frontend/src/components/artistic/ArtisticFlowSteps.jsx      (REWRITE — colapsa por defeito)
- frontend/src/components/artistic/ArtisticStudioTabs.jsx     (sticky tabs)
- frontend/src/i18n/pt.json                                   (novas chaves hero_*)

## Mudanças
1. HERO (Landing)
   - Removido o eyebrow uppercase tracked monoespaçado (substituído por
     badge refinado com glass-morphism).
   - Removida a coluna confusa "See creations / LEARN MORE / SCROLL".
   - CTA principal único + secundários inline (Ver galeria | Saber mais).
   - Subtítulo claro com o valor real do site.
   - Trust strip subtil no fundo.
   - Mais respiração + sombras refinadas no botão (premium feel).

2. ARTISTIC STUDIO
   - "Como funciona" agora é COLLAPSED por defeito (clique para abrir).
     Mostra contador 0/3 → 1/3 → 2/3 → 3/3 conforme progresso.
   - Tabs Gerar/Estilo/Efeitos ficam STICKY no topo durante scroll (sempre
     acessíveis em mobile).
   - Resultado: menos ruído, mais profissional, foco no que importa.

## NÃO precisa de novas dependências.
Validação: cd frontend && yarn build → verde.
